import math

def hamilton(states, seats):
    population = 0.
    for abbrev, value in states.items():
        population += value
    sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    r = {}
    for abbrev, popul in states.items():
        z[abbrev] = 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1)else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        r[abbrev] = q_1[abbrev] - lq[abbrev]
    count = 0
    for lq_value in lq.values():
        count += lq_value
    difference = int(seats - count)
    top_remainders = sorted(r.values())[-difference:]
    extra_seats = [x for x in states.keys() if r[x] in top_remainders]
    for abbrev in extra_seats:
        # the below two lines are equivalent
        #lq[abbrev] = lq[abbrev] + 1
        lq[abbrev] += 1
    return lq

def _get_dict_string(d, offset=0): # for single-valued dictionaries
    output = ''
    for key, value in d.items():
        output += '{}{}: {}\n'.format(' ' * offset, key, value)
    return output

def lowndes(states, seats):
    population = 0.
    for abbrev, value in states.items():
        population += value
    sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    r = {}
    ratio = {}
    for abbrev, popul in states.items():
        z[abbrev] = 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1)else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        r[abbrev] = q_1[abbrev] - lq[abbrev]
        ratio[abbrev] = r[abbrev]/lq[abbrev]
    count = 0
    for lq_value in lq.values():
        count += lq_value
    difference = int(seats - count)
    top_remainders = sorted(ratio.values())[-difference:]
    extra_seats = [x for x in states.keys() if ratio[x] in top_remainders]
    for abbrev in extra_seats:
        # the below two lines are equivalent
        #lq[abbrev] = lq[abbrev] + 1
        lq[abbrev] += 1
    return lq

def _get_dict_string(d, offset=0): # for single-valued dictionaries
    output = ''
    for key, value in d.items():
        output += '{}{}: {}\n'.format(' ' * offset, key, value)
    return output

def _jefferson_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= uq[abbrev]
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def jefferson(states, seats, i_max=10):
    count, sd, q_round  = _jefferson_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _jefferson_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _adams_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= lq[abbrev] 
        q_round[abbrev] = uq [abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def adams(states, seats, i_max=10):
    count, sd, q_round  = _adams_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _adams_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _webster_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= math.sqrt(lq[abbrev] * uq[abbrev]) 
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def webster(states, seats, i_max=10):
    count, sd, q_round  = _webster_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _webster_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _hill_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= math.sqrt(lq[abbrev] * uq[abbrev]) 
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def hill(states, seats, i_max=10):
    count, sd, q_round  = _hill_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _hill_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _dean_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= 2/((1/lq[abbrev])+(1/uq[abbrev])) 
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def dean(states, seats, i_max=10):
    count, sd, q_round  = _dean_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _dean_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

if __name__ == '__main__':
    states = {
        'VA': 630560.,
        'MA': 475327.,
        'PA': 432879.,
        'NC': 353523.,
        'NY': 331589.,
        'MD': 278514.,
        'CT': 236841.,
        'SC': 206236.,
        'NJ': 179570.,
        'NH': 141822.,
        'VT': 85533.,
        'GA': 70835.,
        'KY': 68705.,
        'RI': 68705.,
        'DE': 55540.,
        }
    seats = 105
    
    h2 = hamilton(states, seats)
    print("""
        Hamilton method
        desired: {}
        Hamilton: {}
        Data:
            {}
    """.format(seats, sum(h2.values()), _get_dict_string(h2, offset=8)))

    l1 = lowndes(states, seats)
    print("""
        Lowndes method 
        desired: {}
        Lowndes: {}
        Data:
            {}
    """.format(seats, sum(l1.values()), _get_dict_string(l1, offset=8)))

    j1, j2, j3, j4 = jefferson(states, seats)
    print("""
        Jefferson method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(j1, j2, j3, j4))

    a1, a2, a3, a4 = adams(states, seats)
    print("""
        Adams method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(a1, a2, a3, a4))

    w1, w2, w3, w4 = webster(states, seats)
    print("""
        Webster method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(w1, w2, w3, w4))

    i1, i2, i3, i4 = hill(states, seats)
    print("""
        Hill method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(i1, i2, i3, i4))
    
    d1, d2, d3, d4 = dean(states, seats)
    print("""
        Dean's method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(d1, d2, d3, d4))



