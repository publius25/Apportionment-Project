import math

def hamilton(states, seats):
    population = 0.
    for abbrev, value in states.items():
        population += value
    sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    r = {}
    for abbrev, popul in states.items():
        z[abbrev] = 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1)else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        r[abbrev] = q_1[abbrev] - lq[abbrev]
    count = 0
    for lq_value in lq.values():
        count += lq_value
    difference = int(seats - count)
    top_remainders = sorted(r.values())[-difference:]
    extra_seats = [x for x in states.keys() if r[x] in top_remainders]
    for abbrev in extra_seats:
        # the below two lines are equivalent
        #lq[abbrev] = lq[abbrev] + 1
        lq[abbrev] += 1
    return lq

def _get_dict_string(d, offset=0): # for single-valued dictionaries
    output = ''
    for key, value in d.items():
        output += '{}{}: {}\n'.format(' ' * offset, key, value)
    return output

def lowndes(states, seats):
    population = 0.
    for abbrev, value in states.items():
        population += value
    sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    r = {}
    ratio = {}
    for abbrev, popul in states.items():
        z[abbrev] = 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1)else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        r[abbrev] = q_1[abbrev] - lq[abbrev]
        ratio[abbrev] = r[abbrev]/lq[abbrev]
    count = 0
    for lq_value in lq.values():
        count += lq_value
    difference = int(seats - count)
    top_remainders = sorted(ratio.values())[-difference:]
    extra_seats = [x for x in states.keys() if ratio[x] in top_remainders]
    for abbrev in extra_seats:
        # the below two lines are equivalent
        #lq[abbrev] = lq[abbrev] + 1
        lq[abbrev] += 1
    return lq

def _get_dict_string(d, offset=0): # for single-valued dictionaries
    output = ''
    for key, value in d.items():
        output += '{}{}: {}\n'.format(' ' * offset, key, value)
    return output

def _jefferson_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= uq[abbrev]
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def jefferson(states, seats, i_max=10):
    count, sd, q_round  = _jefferson_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _jefferson_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _adams_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= lq[abbrev] 
        q_round[abbrev] = uq [abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def adams(states, seats, i_max=10):
    count, sd, q_round  = _adams_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _adams_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _webster_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= math.sqrt(lq[abbrev] * uq[abbrev]) 
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def webster(states, seats, i_max=1000):
    count, sd, q_round  = _webster_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _webster_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _hill_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= math.sqrt(lq[abbrev] * uq[abbrev]) 
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def hill(states, seats, i_max=1000):
    count, sd, q_round  = _hill_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _hill_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

def _dean_count(states, seats, sd_override=None):
    if sd_override is not None:
        sd = sd_override
    else:
        population = 0.
        for abbrev, value in states.items():
            population += value
        sd = population/seats
    z = {}
    q = {}
    q_1 = {}
    lq = {}
    uq = {}
    r = {}
    c = {}
    c_diff = {}
    q_round = {}
    for abbrev, popul in states.items():
        z[abbrev]= 1.
        q[abbrev] = popul/sd
        q_1[abbrev] = q[abbrev] if (q[abbrev]>= 1) else z[abbrev]
        lq[abbrev] = math.floor(q_1[abbrev])
        uq[abbrev] = math.ceil(q_1[abbrev]) 
        c[abbrev]= 2/((1/lq[abbrev])+(1/uq[abbrev])) 
        q_round[abbrev] = uq[abbrev] if (q_1[abbrev] >= c[abbrev]) else lq[abbrev]
    count = 0
    for r_var in q_round.values():
        count += r_var
    return count, sd, q_round

def dean(states, seats, i_max=1000):
    count, sd, q_round  = _dean_count(states, seats)
    difference = int(seats - count)
    i = 0
    while (difference != 0):
        if i == i_max:
            break
        pct = difference/seats
        #print(str(difference) + ', ' + str(pct))
        sd -= pct*sd
        count, sd, q_round = _dean_count(states, seats, sd)
        difference = int(seats - count)
        i += 1
    return i, count, sd, q_round

if __name__ == '__main__':
    states = {
        'AL': 4461130.,
        'AK': 628933.,
        'AZ': 5140683.,
        'AR': 2679733.,
        'CA': 33930798.,
        'CO': 4311882.,
        'CT': 3409535.,
        'DE': 785068.,
        'FL': 16028890.,
        'GA': 8206975.,
        'HI': 1216642.,
        'ID': 1297274.,
        'IL': 12439042.,
        'IN': 6090782.,
        'IA': 2931923.,
        'KS': 2693824.,
        'KY': 4049431.,
        'LA': 4480271.,
        'ME': 1277731.,
        'MD': 5307886.,
        'MA': 6355568.,
        'MI': 9955829.,
        'MN': 4925670.,
        'MS': 2852927.,
        'MO': 5606260.,
        'MT': 905316.,
        'NE': 1715369.,
        'NV': 2002032.,
        'NH': 1238415.,
        'NJ': 8424354.,
        'NM': 1823821.,
        'NY': 19004973.,
        'NC': 8067673.,
        'ND': 643756.,
        'OH': 11374540.,
        'OK': 3458819.,
        'OR': 3428543.,
        'PA': 12300670.,
        'RI': 1049662.,
        'SC': 4025061.,
        'SD': 756874.,
        'TN': 5700037.,
        'TX': 20903994.,
        'UT': 2236714.,
        'VT': 609890.,
        'VA': 7100702.,
        'WA': 5908684.,
        'WV': 1813077.,
        'WI': 5371210.,
        'WY': 495304.,
        }
    seats = 435
    
    h2 = hamilton(states, seats)
    print("""
        Hamilton method
        desired: {}
        Hamilton: {}
        Data:
            {}
    """.format(seats, sum(h2.values()), _get_dict_string(h2, offset=8)))

    l1 = lowndes(states, seats)
    print("""
        Lowndes method 
        desired: {}
        Lowndes: {}
        Data:
            {}
    """.format(seats, sum(l1.values()), _get_dict_string(l1, offset=8)))

    j1, j2, j3, j4 = jefferson(states, seats)
    print("""
        Jefferson method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(j1, j2, j3, j4))

    a1, a2, a3, a4 = adams(states, seats)
    print("""
        Adams method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(a1, a2, a3, a4))

    w1, w2, w3, w4 = webster(states, seats)
    print("""
        Webster method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(w1, w2, w3, w4))

    i1, i2, i3, i4 = hill(states, seats)
    print("""
        Hill method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(i1, i2, i3, i4))
    
    d1, d2, d3, d4 = dean(states, seats)
    print("""
        Dean's method
        i: {}
        count: {}
        sd: {}
        q_round: {}
    """.format(d1, d2, d3, d4))



