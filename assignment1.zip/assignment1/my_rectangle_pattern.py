# -*- coding: utf-8 -*-
"""
Created on Wed Sep 22 15:42:52 2021

@author: wolfr
"""

from drawtool import DrawTool 

dt = DrawTool()
dt.set_XY_range(0,100, 0,100)

for i in range(2, 8):
    dt.draw_filled_rectangle(i*10, i*10+10, 5, 10)

dt.display()