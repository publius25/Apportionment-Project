# -*- coding: utf-8 -*-
"""
Created on Wed Sep 22 17:12:09 2021

@author: wolfr
"""

def print_echo():
    for i in range(0,4):
        print('Hello')   

print_echo()