# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 19:27:43 2021

@author: wolfr
"""
 
for i in range(9, 1, -1):
    for n in range(i-1, 8):
        print(' ', end=' ')
    for j in range(i-1, 0, -1):
        print(j, end=' ')
    print(i-1)