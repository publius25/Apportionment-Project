# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 13:39:23 2021

@author: wolfr
"""

# Code for top half: 
for i in range(1, 11): 
    for j in range(0, i):
        print('*', end='')
    print()
    
# Code for bottom half:
for i in range(10, 0, -1):
    for j in range(0, i):
        print('*', end='')
    print()