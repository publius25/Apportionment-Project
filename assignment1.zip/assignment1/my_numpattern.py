# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 19:07:38 2021

@author: wolfr
"""

for i in range(4, 0, -1):
    for j in range(1, 5):
        print(j, i)