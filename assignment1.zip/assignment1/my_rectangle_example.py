# -*- coding: utf-8 -*-
"""
Created on Wed Sep 22 15:42:52 2021

@author: wolfr
"""

from drawtool import DrawTool 

dt = DrawTool()
dt.set_XY_range(0,100, 0,100)

dt.draw_filled_rectangle(10, 20, 5, 10)

dt.display()