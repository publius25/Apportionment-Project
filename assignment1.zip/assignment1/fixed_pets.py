# -*- coding: utf-8 -*-
"""
Created on Wed Sep 22 17:00:18 2021

@author: wolfr
"""

print('The dog says, "I\'m a good boy!\"')
print("The cat says, \"Leave me alone...\"")     
