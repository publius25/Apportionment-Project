# -*- coding: utf-8 -*-
"""
Created on Mon Sep 20 15:40:43 2021

@author: wolfr
"""

for j in range(0,7):
    print('*')