# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 13:33:28 2021

@author: wolfr
"""

for i in range(1, 10):
    # Print i *'s
    for j in range(0,i):
        print('*', end='')
        