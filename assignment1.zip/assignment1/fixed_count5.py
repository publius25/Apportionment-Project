# -*- coding: utf-8 -*-
"""
Created on Wed Sep 22 17:17:15 2021

@author: wolfr
"""

def count_to_five():
    for i in range(5):
        print(i)
print('Here is how you count to 5...')
count_to_five()
print('And that is how you count to 5!')
    